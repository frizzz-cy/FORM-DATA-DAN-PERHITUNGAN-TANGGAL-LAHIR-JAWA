<div class="panel-header bg-primary-gradient">
    <div class="page-inner py-5">
        <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
            <div>
                <h2 class="text-white pb-2 fw-bold">Beranda</h2>
                <h5 class="text-white op-7 mb-2">Halaman Beranda Informasi Sistem</h5>
            </div>
        </div>
    </div>
</div>
<div class="page-inner mt--5">
    <div class="row mt--2">
        <div class="col-md-3">
            <div class="card card-success">
                <div class="card-header">
                    <div class="card-title">Data 1</div>
                </div>
                <div class="card-body pb-0">
                    <div class="mb-4 mt-2">
                        <h1>123456</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card card-info">
                <div class="card-header">
                    <div class="card-title">Data 2</div>
                </div>
                <div class="card-body pb-0">
                    <div class="mb-4 mt-2">
                        <h1>123456</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card card-warning">
                <div class="card-header">
                    <div class="card-title">Data 3</div>
                </div>
                <div class="card-body pb-0">
                    <div class="mb-4 mt-2">
                        <h1>123456</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card card-danger">
                <div class="card-header">
                    <div class="card-title">Data 4</div>
                </div>
                <div class="card-body pb-0">
                    <div class="mb-4 mt-2">
                        <h1>123456</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- card -->
<div class="card-body">
    <div id="row-demo-icon" class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Font Awesome Icons</div>
                    <div class="card-category">Modern Font Icon from <a class="link" href="https://fontawesome.com">Font
                            Awesome</a></div>
                </div>
                <div class="card-body">
                    <div id="row-demo-icon" class="row">
                        <div class="col-md-3">
                            <div class="demo-icon">
                                <div class="icon-preview"><i class="fas fa-address-book"></i></div>
                                <div class="icon-class">fas fa-address-book</div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="demo-icon">
                                <div class="icon-preview"><i class="fas fa-address-card"></i></div>
                                <div class="icon-class">fas fa-address-card</div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="demo-icon">
                                <div class="icon-preview"><i class="fas fa-adjust"></i></div>
                                <div class="icon-class">fas fa-adjust</div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="demo-icon">
                                <div class="icon-preview"><i class="fas fa-air-freshener"></i></div>
                                <div class="icon-class">fas fa-air-freshener</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card-body">
    <div id="row-demo-icon" class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Simple Line Icons</div>
                    <div class="card-category">Simple and Minimal Line icons from <a class="link"
                            href="https://github.com/thesabbir/simple-line-icons">Simple Line Icons</a></div>
                </div>
                <div class="card-body">
                    <div id="row-demo-icon" class="row">
                        <div class="col-md-3">
                            <div class="demo-icon">
                                <div class="icon-preview"><i class="icon-user"></i></div>
                                <div class="icon-class">icon-user</div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="demo-icon">
                                <div class="icon-preview"><i class="icon-people"></i></div>
                                <div class="icon-class">icon-people</div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="demo-icon">
                                <div class="icon-preview"><i class="icon-user-female"></i></div>
                                <div class="icon-class">icon-user-female</div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="demo-icon">
                                <div class="icon-preview"><i class="icon-user-follow"></i></div>
                                <div class="icon-class">icon-user-follow</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="card-body">
    <div id="row-demo-icon" class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Flaticons</div>
                    <div class="card-category">Flaticons from <a class="link"
                            href="https://www.flaticon.com/authors/smashicons">Smashicons</a></div>
                </div>
                <div class="card-body">
                    <div class="card-body">
                        <div id="row-demo-icon" class="row">
                            <div class="col-md-3">
                                <div class="demo-icon">
                                    <div class="icon-preview"><i class="la flaticon-delivery-truck"></i></div>
                                    <div class="icon-class">flaticon-delivery-truck</div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="demo-icon">
                                    <div class="icon-preview"><i class="la flaticon-shopping-bag"></i></div>
                                    <div class="icon-class">flaticon-shopping-bag</div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="demo-icon">
                                    <div class="icon-preview"><i class="la flaticon-box-3"></i></div>
                                    <div class="icon-class">flaticon-box-3</div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="demo-icon">
                                    <div class="icon-preview"><i class="la flaticon-box-2"></i></div>
                                    <div class="icon-class">flaticon-box-2</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>