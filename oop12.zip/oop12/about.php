|<div class="row mt-5">
    <div class="col-md-6 ml-auto mr-auto">
        <p class="row" style="text-align:justify; font-size: 20px;">
            <img src="assets/img/bg-abstract2.png"
                style="margin-bottom: 25px; display:block; margin-left: auto; margin-right:auto; text-align:center; width: 50%; border-radius: 15px;">
            Praktikum ini merupakan praktikum matakuliah Pemrograman Berbasis Obyek yang membuat website berbasis
            modular dengan
            menggunakan Framework CSS Varian Bootstrap yaitu Atlantis Lite Master</p>
        </p>
    </div>
</div>