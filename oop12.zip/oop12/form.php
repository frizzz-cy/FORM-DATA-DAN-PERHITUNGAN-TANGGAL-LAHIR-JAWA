<div class="row mt-5">
    <div class="col-md-6 ml-auto mr-auto">
        <div class="card">
            <div class="card-header">
                <div class="card-title">Form Hari Kelahiran & Pasaran</div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <form method="post">
                            <div class="form-group">
                                <label>Isi Tanggal Lahir</label>
                                <input type="date" class="form-control" name="texttgllahir" style="font-size :20px;">
                                <small class="form-text text-muted">Isi Sesuai Dengan Format yang muncul</small>
                            </div>
                            <div class="form-group">
                                <button type="submit" name="btnhitung" class="btn btn-primary">Tampilkan</button>
                                <button type="reset" class="btn btn-danger">Reset</button>
                            </div>
                        </form>
                        <div class="form-group">
                            <p id="blokhasil" style="font-size: 36px;">
                                <?php
                                if (isset($_REQUEST["btnhitung"])) {
                                    //----Perhitungan hari kelahiran----
                                    $terjemahhari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
                                    $tgllahir = $_REQUEST["txttgllahir"];
                                    $hari = $terjemahhari[date("w", strtotime(date($tgllahir)))];
                                    //----Perhitungan pasaran----
                                    $terjemahpasar = ["Kliwon", "Legi", "Pahing", "Pon", "Wage"];
                                    $tglawal = "1900-01-04";
                                    $x = explode("-", $tglawal);
                                    $tahun1 = $x[0];
                                    $bulan1 = $x[1];
                                    $tgl1 = $x[2];
                                    $x = explode("-", $tgllahir);
                                    $tahun2 = $x[0];
                                    $bulan2 = $x[1];
                                    $tgl2 = $x[2];
                                    $jd1 = GregorianToJD($bulan1, $tgl1, $tahun1);
                                    $jd2 = GregorianToJD($bulan2, $tgl2, $tahun2);
                                    $selisih = $jd2 - $jd1;
                                    $hasil = floor($selisih) % 5;
                                    $pasaran = $terjemahpasar[$hasil];
                                    echo "Hari Kelahiran: $hari $pasaran";
                                } else {
                                    echo "Hari Kelahiran: ?????";
                                }
                                ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>