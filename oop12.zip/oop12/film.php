<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktek oop3</title>
    <link rel="stylesheet" href="index.css" />
    <style>
    html,
    body,
    section {
        height: 100%;
    }

    html {
        scroll-behavior: smooth;
    }

    body {
        font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman'serif;
    }

    section {
        display: block;
        padding: 25px;
    }

    a {
        color: white;
        text-decoration: none;
    }

    #film {
        background-color: chocolate;
        color: white;
    }

    #youtube {
        background-color: grey;
        color: white;
    }

    #sosmed {
        background-color: teal;
        color: white;
    }

    #film div h1,
    #youtube div h1,
    #sosmed div h1 {
        width: 50%;
    }

    .posisi_kanan {
        text-align: right;
    }

    #film div,
    #youtube div,
    #sosmed div {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
    }

    #film div a {
        width: calc((100% - 90px)/7);
    }

    #film div a img {
        width: 100%;
        border-radius: 15px;
    }

    #youtube #blokyoutube iframe {
        width: calc((100% - 50px)/2);
    }

    tr {
        height: 150px;
        font-size: 35px;
        text-align: center;
    }
    </style>
</head>

<body>
    <div class="container">
        <nav class="wrapper">
            <div class="brand-name">
                <div id="name1">Crazy</div>
                <div id="name2">Code</div>

            </div>
            <ul class="navigation">
                <li><a href="#">FILM</a></li>
                <li><a href="#">VIDEO YOUTUBE</a></li>
                <li><a href="#">SOSIAL MEDIA</a></li>
            </ul>
            <img id="imgx" src="img/1.png">
            </li>
        </nav>
    </div>
    <section id="film">
        <div>
            <h1>Film</h1>
            <h1 class="posisi_kanan"><a href="#youtube">Ke youtube</a></h1>
        </div>
        <div style="gap: 15px;">
            <a href="https://www.imdb.com/title/tt2463208" target="_blank">
                <img src="img/adam_project_xlg.jpg" alt=". . .">
            </a>
            <a href="https://www.imdb.com/title/tt13314558" target="_blank">
                <img src="img/day_shift_xlg.jpg" alt=". . .">
            </a>
            <a href="https://www.imdb.com/title/tt13634480" target="_blank">
                <img src="img/ice_age_adventures_of_buck_wild_ver7_xlg.jpg" alt=". . .">
            </a>
            <a href="https://www.imdb.com/title/tt11671006" target="_blank">
                <img src="img/man_from_toronto_xlg.jpg" alt=". . .">
            </a>
            <a href="https://www.imdb.com/title/tt8466564" target="_blank">
                <img src="img/obiwan_kenobi_a_jedis_return_xlg.jpg" alt=". . .">
            </a>
            <a href="https://www.imdb.com/title/tt15314262" target="_blank">
                <img src="img/beekeeper.jpg" alt=". . .">
            </a>
            <a href="https://www.imdb.com/title/tt17279496" target="_blank">
                <img src="img/civil_war_ver2.jpg" alt=". . .">
            </a>
            <a href="https://www.imdb.com/title/tt15239678" target="_blank">
                <img src="img/dune_part_two_ver13.jpg" alt=". . .">
            </a>
            <a href="https://www.imdb.com/title/tt11858890" target="_blank">
                <img src="img/creator_ver4_xlg.jpg" alt=". . .">
            </a>
            <a href="https://www.imdb.com/title/tt11389872" target="_blank">
                <img src="img/kingdom_of_the_planet_of_the_apes_xlg.jpg" alt=". . .">
            </a>
            <a href="https://www.imdb.com/title/tt9471678" target="_blank">
                <img src="img/ultraman_rising_xlg.jpg" alt=". . .">
            </a>

            <a href="https://www.imdb.com/title/tt10954600" target="_blank">
                <img src="img/antman_and_the_wasp_quantumania_ver4_xlg.jpg" alt=". . .">
            </a>

            <a href="https://www.imdb.com/title/tt9362930" target="_blank">
                <img src="img/blue_beetle_ver4_xlg.jpg" alt=". . .">
            </a>
            <a href="https://www.imdb.com/title/tt2906216" target="_blank">
                <img src="img/dungeons_and_dragons_honor_among_thieves_ver2_xlg.jpg" alt=". . .">
            </a>

        </div>
    </section>
    <section id="youtube">
        <div>
            <h1>youtube</h1>
            <h1 class="posisi_kanan"><a href="#sosmed">Ke sosial media</a></h1>
        </div>
        <div id="blokyoutube" style="gap: 50px;">
            <iframe width="916" height="550" src="https://www.youtube.com/embed/fax7Ltu1fOU"
                title="Praktikum 2 (Membuat Aplikasi Mobile Sederhana Berbasis Framework7 dan JQuery)" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen></iframe>
            <iframe width="916" height="550" src="https://www.youtube.com/embed/H-umE1SvXAQ"
                title="Praktikum 7a (Menerapkan Library Flashlight pada Project Cordova)" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen></iframe>
        </div>
    </section>
    <section id="sosmed">
        <div>
            <h1>sosial media</h1>
            <h1 class="posisi_kanan"><a href="#film">ke film</a></h1>
        </div>
        <div>
            <table style="width: 100%;">
                <tr>
                    <td style="width: 30%; background-color: #c62828">
                        <a href="https://facebook.com" target="_blank">facebook</a>
                    </td>
                    <td style="width: 30%; background-color: #c62828">
                        <a href="https://linkedin.com" target="_blank">linkedin</a>
                    </td>
                </tr>
                <tr>
                    <td style="width: 30%; background-color: #6a1b9a;">
                        <a href="https://Twitter.com" target="_blank">Twitter</a>
                    </td>
                    <td style="width: 30%; background-color: #512da8;">
                        <a href="https://youtube.com" target="_blank">Youtube</a>
                    </td>
                    <td style="width: 30%; background-color: #0097a7;">
                        <a href="https://pinterest.com" target="_blank">Pinterest</a>
                    </td>
                </tr>
                <tr>
                    <td style="width: 30%; background-color: #f57f17;">
                        <a href="https://vimeo.com" target="_blank">vimeo</a>
                    </td>
                </tr>

            </table>
        </div>
    </section>


</body>

</html>